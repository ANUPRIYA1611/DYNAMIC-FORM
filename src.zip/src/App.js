import logo from './logo.svg';
import './App.css';
import DynamicForm from './components/dynamic';
function App() {
  return (
    <div className="App">
      <DynamicForm></DynamicForm>
    </div>
  );
}
export default App;